let mobileMenu = document.querySelector('.mobile-menu')

document.querySelector('#mobile').onclick=() =>{
    mobileMenu.classList.toggle('active')
}